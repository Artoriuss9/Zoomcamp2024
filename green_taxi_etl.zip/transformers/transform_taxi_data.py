if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def transform(data, *args, **kwargs):
    #print(f'Preprocessing: rows with zero passengers: {data['passenger_count].isin([0]).sum()}')

    #Remove rows where the passenger count is equal to 0 or the trip distance is equal to zero.
    print("rows with zero passengers:", data['passenger_count'].isin([0]).sum())
    print("rows with zero trips:", data['trip_distance'].isin([0]).sum())

    #Create a new column lpep_pickup_date by converting lpep_pickup_datetime to a date
    data['lpep_pickup_date'] = data['lpep_pickup_datetime'].dt.date

    #Rename columns in Camel Case to Snake Case
    data.columns  = data.columns.str.replace('(?<=[a-z])(?=[A-Z])', '_', regex=True).str.lower()

    # Rename columns from Camel Case to Snake Case
    #data.columns = [col[0].lower() + col[1:] for col in data.columns]
    #data = df.rename(columns={col: '_'.join(col.split()) for col in data.columns})

    #data.columns = [col.lower().replace(' ', '_') for col in data.columns]   

    data = data[(data['passenger_count'] > 0) & (data['trip_distance'] > 0)]

    return data
    

@test
def test_output(output, *args):
    assert output['vendor_id'].nunique(), 'there are duplicates in the column vendor_id'
    assert output['passenger_count'].isin([0]).sum() >= 0, 'passenger_count is not greater than 0'
    assert output['trip_distance'].isin([0]).sum() >= 0, 'there are rides that is not greater than 0'
